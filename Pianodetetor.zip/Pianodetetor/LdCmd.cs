﻿using CShapDM;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Point = System.Drawing.Point;

namespace LdAdb
{

    public class LdCmd
    {
        CDmSoft dm = new CDmSoft();
        /// <summary>
        /// 模拟器安装路径
        /// </summary>
        public string SimulatorPath { get; set; }
        public static readonly object obj = new object();
        private static LdCmd ldCmd = null;

        public LdCmd()
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\ChangZhi\LDPlayer");

            if (key == null)
            {
                MessageBox.Show("Không tìm thấy đường dẫn ldplayer 4 , vui lòng cài đặt nếu bạn chưa cài");
            }
            object objRegisteredValue = key.GetValue("InstallDir");
            string SimulatorPath = objRegisteredValue.ToString();
        }
        public static LdCmd GetObject()
        {
            if (ldCmd == null)
            {
                lock (obj)
                {
                    if (ldCmd == null)
                    {
                        ldCmd = new LdCmd();
                    }
                }
            }
            return ldCmd;
        }
        /// <summary>
        /// 执行CMD窗口信息
        /// </summary>
        /// <param name="value">模拟器命令</param>
        /// <returns>执行后的信息</returns>
        private string ImplementCmd(string value)
        {
            Process p = new Process();
            //设置要启动的应用程序
            p.StartInfo.FileName = "adb.exe";
            p.StartInfo.Arguments = value;
            //是否使用操作系统shell启动
            p.StartInfo.UseShellExecute = false;
            // 接受来自调用程序的输入信息
            p.StartInfo.RedirectStandardInput = true;
            //输出信息
            p.StartInfo.RedirectStandardOutput = true;
            // 输出错误
            p.StartInfo.RedirectStandardError = true;
            //不显示程序窗口
            p.StartInfo.CreateNoWindow = true;
            //启动程序
            p.Start();
            //向cmd窗口发送输入信息
            p.StandardInput.AutoFlush = true;
            //获取输出信息
            string strOuput = p.StandardOutput.ReadToEnd();
            //等待程序执行完退出进程
            if (p.WaitForExit(10000))
                p.Close();
            else
                p.Kill();


            return strOuput;
        }
        public  string RunCmd(string executeString)
        {
            Process p = new Process();
            //setup 要启动的应用程序
            p.StartInfo.FileName = "cmd.exe";
            //是否使用操作系统shell启动
            p.StartInfo.UseShellExecute = false;
            // 接受来自调用程序的输入信息
            p.StartInfo.RedirectStandardInput = true;
            //输出信息
            p.StartInfo.RedirectStandardOutput = true;
            // 输出错误
            p.StartInfo.RedirectStandardError = true;
            //不显示程序窗口
            p.StartInfo.CreateNoWindow = true;


            //启动程序
            p.Start();
            //向cmd窗口发送输入信息
            p.StandardInput.WriteLine(executeString);
            p.StandardInput.WriteLine("exit");
            p.StandardInput.AutoFlush = true;
            //获取输出信息
            string strOuput = p.StandardOutput.ReadToEnd();
            //等待程序执行完退出进程
            if (p.WaitForExit(10000))
                p.Close();
            else
                p.Kill();

            return strOuput;
        }
        public string Bat(string value)
        {
            // tạo name file bat 
            var batfile = Guid.NewGuid()+".bat";
            //get temp forder
            string result = Path.GetTempPath();
            //lấy path thư mục hiện tại 
            string path = Directory.GetCurrentDirectory();
            //bắt dầu ghi vào file bat
            StreamWriter sw = new StreamWriter(result + batfile);

           // ghi nội dung vào file
            sw.WriteLine(path+"\\adb " + value);
            // nội dung dele file bat khi chạy xong
            sw.WriteLine("DEL \"%~f0\" & EXIT");
            //thoát ghi
            sw.Close();

            return RunCmd(result + batfile);
        }
        public string Bat1(string value)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\XuanZhi\LDPlayer");

            if (key == null)
            {
                MessageBox.Show("Không tìm thấy đường dẫn ldplayer 4 , vui lòng cài đặt nếu bạn chưa cài");
            }
            object objRegisteredValue = key.GetValue("InstallDir");
            string SimulatorPath = objRegisteredValue.ToString();
            var batfile = Guid.NewGuid() + ".bat";
            string result = Path.GetTempPath();
            string path = Directory.GetCurrentDirectory();
            StreamWriter sw = new StreamWriter(result + batfile);

            // sw.WriteLine("adb "+value);
            sw.WriteLine(value);
            sw.WriteLine("DEL \"%~f0\" & EXIT");
            sw.Close();

            return RunCmd(result + batfile);
        }
        /// <summary>
        /// 启动应用
        /// </summary>
        /// <param name="index">模拟器序号</param>
        /// <param name="value">包名/Activity类名</param>
        /// <returns></returns>
        public string StartApp(string name, string value)
        {
            return Bat(
                    string.Format("-s {0} shell am start -n {1}", name, value));
        }
        /// <summary>
        /// 获取界面控件类名
        /// </summary>
        /// <param name="index">模拟器序号</param>
        /// <returns></returns>
        public string GetAndroidClass(string name)
        {
            return Bat(string.Format("-s {0} shell dumpsys activity | findstr mFocusedActivity", name));
        }
        /// <summary>
        /// 查看已创建的模拟器状态 PS：依次是：索引,标题,顶层窗口句柄,绑定窗口句柄,是否进入android,进程PID,VBox进程PID
        /// </summary>
        /// <returns>返回List集合</returns>
        public List<string> ListSimulator()
        {
            lock (obj)
            {
                List<string> list = new List<string>();
                string[] str = ImplementCmd(string.Format("devices")).Split(new char[2] { '\r', '\n' });
                //foreach (Match item in match)
                //{
                //    if (item.Value.Contains("0")
                //        || item.Value.Contains("1")
                //        || item.Value.Contains("2")
                //        || item.Value.Contains("3")
                //        || item.Value.Contains("4")
                //        || item.Value.Contains("5")
                //        || item.Value.Contains("6")
                //        || item.Value.Contains("7")
                //        || item.Value.Contains("8")
                //        || item.Value.Contains("9"))
                //    {
                //        list.Add(item.Value);
                //    }
                //}
                for (int i = 1; i < str.Length; i++)
                {
                    if (str[i].Length > 7)
                    {
                        list.Add(str[i].Split('\t')[0]);
                    }
                }
                return list;
            }
        }
        /// <summary>
        /// 点击位置
        /// </summary>
        /// <param name="name">设备名</param>
        /// <param name="location">坐标</param>
        /// <returns></returns>
        public string ClickLocation(string name, string location)
        {
            return Bat(string.Format("-s {0} shell input tap {1}", name, location));
        }
        /// <summary>
        /// 模拟按键
        /// </summary>
        /// <param name="name"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public string Keyevent(string name, int key)
        {
            return Bat(string.Format("-s {0} shell input keyevent {1}", name, key));
        }
        /// <summary>
        /// Simulate mouse swipe
        /// </summary>
        /// <param name="name">Device name</param>
        /// <param name="position">Coordinate PS：X1 Y1 X2 Y2</param>
        /// <returns></returns>
        public string InputSwipt(string name, string position)
        {

            return Bat(
                string.Format("-s {0} shell input swipe {1}", name, position));
        }

        public string InputText(string name, string text)
        {
            string newtext = text.Replace(" ", "\\ ");
            return Bat(
                string.Format("-s {0} shell input text {1}", name, newtext));
        }
        /// <summary>
        /// 启动服务
        /// </summary>
        /// <returns></returns>
        public string StartServer()
        {
            return ImplementCmd(string.Format("start-server"));
        }
        /// <summary>
        /// 杀死服务
        /// </summary>
        /// <returns></returns>
        public string RestartServer()
        {
            return ImplementCmd(string.Format("kill-server&&adb start-server"));
        }
        /// <summary>
        /// 飞行模式
        /// </summary>
        /// <param name="name">设备</param>
        /// <param name="value">1：打开飞行模式  0：关闭飞行模式</param>
        /// <returns></returns>
        public string FlightMode(string name, string value)
        {
            return Bat(string.Format("-s {0} shell settings put global airplane_mode_on {1}", name, value));
        }
        /// <summary>
        /// 通知系统已经打开飞行模式
        /// </summary>
        /// <param name="name">设备</param>
        /// <param name="value">true:打开飞行模式  false：关闭飞行模式</param>
        /// <returns></returns>
        public string Broadcast(string name, bool value)
        {
            return Bat(string.Format("-s {0} shell am broadcast -a android.intent.action.AIRPLANE_MODE --ez state {1}", name, value));
        }
        /// <summary>
        /// 截图并保存在电脑
        /// </summary>
        /// <param name="name">设备</param>
        /// <returns></returns>
        public string Screenshot(string name)
        {
            return Bat(
                string.Format("-s {0} shell screencap -p /sdcard/Pictures/test.png", name));
        }
        /// <summary>
        /// 清理app缓存
        /// </summary>
        /// <param name="name">设备</param>
        /// <param name="packName">包名</param>
        /// <returns></returns>
        public string ClearApp(string name, string packName)
        {
            return Bat(string.Format("-s {0} shell pm clear {1}", name, packName));
        }
        /// <summary>
        /// 卸载应用
        /// </summary>
        /// <param name="name">设备</param>
        /// <param name="packName">包名</param>
        /// <returns></returns>
        public string Uninstall(string name, string packName)
        {
            return Bat(string.Format("-s {0} uninstall {1}", name, packName));
        }
        /// <summary>
        /// 安装应用
        /// </summary>
        /// <param name="name">设备</param>
        /// <param name="appPath">APK路径</param>
        /// <returns></returns>
        public string Install(string name, string appPath)
        {
            return Bat(string.Format("-s {0} install -sg {1}", name, appPath));
        }
        /// <summary>
        /// 复制电脑文件到手机上
        /// </summary>
        /// <param name="name">设备</param>
        /// <param name="filePath">文件路径</param>
        /// <returns></returns>
        public string Push(string name, string filePath)
        {
            return Bat(string.Format("-s {0} push {1} {2}", name, filePath, "APP"));
        }
        /// <summary>
        /// startweb
        /// </summary>
        /// <param name="device">127.0.0.1:5555</param>
        /// <param name="website">https://www.payoneer.com</param>
        /// <returns></returns>
        public string StartWeb(string device, string website)
        {
            return Bat(
                string.Format(" -s {0} shell am start -a \"android.intent.action.VIEW\" -d {1}", device, website));
        }
        /// <summary>
        /// Wipedata
        /// </summary>
        /// <param name="device">Simulator number</param>
        /// <param name="packageName">App package name</param>
        /// <returns></returns>

        public Point FindUI(string device, string textfind)
        {
            int Mydevice = 0;
            string path = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            //pathld only
            string pathldshare = (path + "\\XuanZhi\\Pictures\\");
            Bat(string.Format("-s {0} shell uiautomator dump /sdcard/Pictures/android{1}.xml", device, Mydevice.ToString()));
            var pathtoread = pathldshare + "android" + Mydevice + ".xml";
            string html;
            lock (obj)
            {
                using (StreamReader sr = new StreamReader(pathtoread))
                {

                    html = sr.ReadToEnd();
                    sr.Close();
                    sr.Dispose();

                }
            }

            //  text = text.Replace("/", "\\/");
            //  text = text.Replace("[", "\\[");

            Match point = Regex.Match(html, "" + textfind + "[^>]*bounds=\"\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]");

            if (point.Groups[1].Value == "")
            {

                return new Point(-1, -1);
            }
            int x = (int.Parse(point.Groups[1].Value) + int.Parse(point.Groups[3].Value)) / 2;
            int y = (int.Parse(point.Groups[2].Value) + int.Parse(point.Groups[4].Value)) / 2;

            return new Point(x, y);

        }
        public int WaitUI(string device, string textfind, int delay)
        {
            var point = FindUI(device, textfind);
            var cord = point.ToString();
            cord = cord.Replace(",", ";");
            int x = 0;
            while (cord == "-1;-1")
            {
                System.Threading.Thread.Sleep(1000);

                point = FindUI(device, textfind);
                cord = point.ToString();
                cord = cord.Replace(",", ";");
                if (cord != "-1;-1") break;
                x++;
                if (x >= delay)
                    return 0;
            }
            return 1;
        }
        public int ClickUI(string device, string textfind, int delay)
        {
            var point = FindUI(device, textfind);
            var cord = point.ToString();
            cord = cord.Replace(",", ";");
            int x = 0;


            while (cord == "-1;-1")
            {
                System.Threading.Thread.Sleep(1000);

                point = FindUI(device, textfind);
                cord = point.ToString();
                cord = cord.Replace(",", ";");
                if (cord != "-1;-1") break;
                x++;
                if (x >= delay)
                    return 0;
            }
            cord = cord.Replace(";", " ");
            ClickLocation(device, cord);
            return 1;
        }
        public int InputUI(string device, string textfind, string text, int delay)
        {
            var point = FindUI(device, textfind);
            var cord = point.ToString();
            cord = cord.Replace(",", ";");

            int x = 0;
            while (cord == "-1;-1")
            {
                System.Threading.Thread.Sleep(1000);

                point = FindUI(device, textfind);
                cord = point.ToString();
                cord = cord.Replace(",", ";");
                if (cord != "-1;-1") break;
                x++;
                if (x >= delay)
                    return 0;
            }
            cord = cord.Replace(";", " ");
            ClickLocation(device, cord);
            InputText(device, text);
            return 1;
        }
        public bool cord(string device, int handle)
        {
            lock (obj)
            {
                int Mydevice = 99;
            string path = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            //pathld only
            string pathldshare = (path + "\\XuanZhi\\Pictures\\");
            Bat(string.Format("-s {0} shell uiautomator dump /sdcard/Pictures/android{1}.xml", device, Mydevice.ToString()));
            var pathtoread = pathldshare + "android" + Mydevice + ".xml";
            string html;
            
                using (StreamReader sr = new StreamReader(pathtoread))
                {

                    html = sr.ReadToEnd();
                    sr.Close();
                    sr.Dispose();

                }
            
            //  text = text.Replace("/", "\\/");
            //  text = text.Replace("[", "\\[");

            Match point = Regex.Match(html, "resource-id=\"partners_default_accountregistration_ctl00_cphbodycontent_accountdetails1_accountdetailscaptcha_CaptchaImage[^>]*bounds=\"\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]");

            if (point.Groups[1].Value == "")
            {

                return false;
            }

            int x1 = int.Parse(point.Groups[1].Value);
            int y1 = int.Parse(point.Groups[2].Value);
            int x2 = int.Parse(point.Groups[3].Value);
            int y2 = int.Parse(point.Groups[4].Value);
            dm.BindWindowEx(handle, "gdi", "windows", "windows", "", 0);
            dm.CapturePng(x1, y1, x2, y2, "temp.png");

            return true;
            }
        }
        /// <summary>
        /// Nhập unicode only for LDplayer 
        /// </summary>
        /// <param name="index">0</param>
        /// <param name="value">Text unicode</param>
        /// <returns></returns>
        public string InputUnicode(int index, string value)
        {
            lock (obj)
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\XuanZhi\LDPlayer");

                if (key == null)
                {
                    MessageBox.Show("Không tìm thấy đường dẫn ldplayer 4 , vui lòng cài đặt nếu bạn chưa cài");
                }
                object objRegisteredValue = key.GetValue("InstallDir");
                string SimulatorPath = objRegisteredValue.ToString();

                return Bat1(
                    string.Format("{0}dnconsole action --index {1} --key call.input --value {2}", SimulatorPath, index, value));
            }
        }
        public void imei_gen(int firstnumber,int secondnumber)
        {
            Random rd = new Random();
            int pos;
            int[] str = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            var sum = 0;
            var final_digit = 0;
            int t = 0;
            var len_offset = 0;
            var len = 15;


            //
            // Fill in the first two values of the string based with the specified prefix.
            // Reporting Body Identifier list: http://en.wikipedia.org/wiki/Reporting_Body_Identifier
            //

            //int[] rbi = { 10, 30, 33, 35, 44, 45, 49, 50, 51, 52, 53, 54, 86, 91, 98, 99 };
            
            str[0] = firstnumber;
            str[1] = secondnumber;
           
            pos = 2;

            //
            // Fill all the remaining numbers except for the last one with random values.
            //

            while (pos < len - 1)
            {
                pos++;
                str[pos] = rd.Next(0, 9);
               
            }

            //
            // Calculate the Luhn checksum of the values thus far.
            //

            len_offset = (len + 1) % 2;
            MessageBox.Show(len_offset.ToString());
            for (pos = 0; pos < (len - 1); pos++)
            {
                if ((pos + len_offset) % 2 == 0)
                {
                    t = str[pos] * 2;
                    if (t > 9)
                    {
                        t -= 9;
                    }
                    sum += t;
                }
                else
                {
                    sum += str[pos];
                }
               MessageBox.Show(str[pos].ToString() + " " + sum.ToString());
            }

            //
            // Choose the last digit so that it causes the entire string to pass the checksum.
            //
            MessageBox.Show(sum.ToString());
            int luhn = sum % 10;
            if (luhn != 0)
                {
                luhn = 10 - luhn;
                }
            final_digit = (10 - sum % 10) % 10;
            MessageBox.Show(luhn.ToString());
            //str[(len - 1)] = final_digit;
           // MessageBox.Show(final_digit.ToString());
            pos = 2;
            string ttt = str[0].ToString() + str[1].ToString();
            while (pos < len - 1)
            {
                pos++;
                ttt = ttt + str[pos].ToString();
               
            }
            string imei = ttt + luhn.ToString();
            MessageBox.Show(imei);
            // Output the IMEI value.
            //string tt = string.Join(",", str.Select(str => str.ToString()).ToArray());
            //  tt = tt.Substring(0, len);
            //MessageBox.Show(tt);


        }
        public void changedevice(int index,string device,string manu,string phone)
        {
            lock (obj)
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\XuanZhi\LDPlayer");

                if (key == null)
                {
                    MessageBox.Show("Không tìm thấy đường dẫn ldplayer 4 , vui lòng cài đặt nếu bạn chưa cài");
                }
                object objRegisteredValue = key.GetValue("InstallDir");
                string SimulatorPath = objRegisteredValue.ToString();
                
                Bat1(
                    string.Format("{0}dnconsole quit --index {1}", SimulatorPath, index));
                System.Threading.Thread.Sleep(2000);
               
                Bat1(string.Format("{0}dnconsole modify --index {1} --manufacturer \"{2}\" --model \"{3}\" --pnumber {4} --imei auto --imsi auto --simserial auto --androidid auto --mac auto --resolution 540,960,160", SimulatorPath, index, manu, device, phone));
   
            }
        }
        public string Reboot(int index)
        {
            lock (obj)
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\XuanZhi\LDPlayer");

                if (key == null)
                {
                    MessageBox.Show("Không tìm thấy đường dẫn ldplayer 4 , vui lòng cài đặt nếu bạn chưa cài");
                }
                object objRegisteredValue = key.GetValue("InstallDir");
                string SimulatorPath = objRegisteredValue.ToString();
                Bat1(
                    string.Format("{0}dnconsole quit --index {1}", SimulatorPath, index));
                System.Threading.Thread.Sleep(2000);
                return Bat1(
                   string.Format("{0}dnconsole launch --index {1}", SimulatorPath, index));
            }
        }
        public string Isrunning(int index)
        {
            lock (obj)
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\XuanZhi\LDPlayer");

                if (key == null)
                {
                    MessageBox.Show("Không tìm thấy đường dẫn ldplayer 4 , vui lòng cài đặt nếu bạn chưa cài");
                }
                object objRegisteredValue = key.GetValue("InstallDir");
                string SimulatorPath = objRegisteredValue.ToString();

                string str = Bat1(string.Format("{0}dnconsole isrunning --index {1}", SimulatorPath, index));

                if (str.Contains("stop"))
                {


                    return Bat1(string.Format("{0}dnconsole launch --index {1}", SimulatorPath, index));
                    
                }
               
                return "running";
            }
        }
        /// <summary>
        /// setup resolution
        /// </summary>
        /// <param name="index">Index emulator</param>
        /// <param name="value">w,h,dpi</param>
        /// <returns></returns>
        public string SetResolution(int index, string value)
        {
            lock (obj)
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\XuanZhi\LDPlayer");

                if (key == null)
                {
                    MessageBox.Show("Không tìm thấy đường dẫn ldplayer 4 , vui lòng cài đặt nếu bạn chưa cài");
                }
                object objRegisteredValue = key.GetValue("InstallDir");
                string SimulatorPath = objRegisteredValue.ToString();
                return Bat1(string.Format("{0}dnconsole modify --index {1} --resolution {2} --lockwindow 1", SimulatorPath, index, value));
            }
        }
    } }
