﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LdAdb;
using Funcdm;
using CShapDM;

namespace Pianodetetor
{
    public partial class Form1 : Form
    {
        funcdm fun = new funcdm();
        LdCmd adb = new LdCmd();
        CDmSoft dm = new CDmSoft();
        private int intX, intY;
        private object x, y;

        private void button2_Click(object sender, EventArgs e)
        {
            int handle = fun.gethandle();
            //   dm.ForceUnBindWindow(handle);
            dm.BindWindowEx(handle, "gdi", "windows", "windows", "", 0);
            var ret = dm.Capture(0, 0, 2000, 2000, "test.bmp");
            //int[] test = fun.FindXYImage(handle, "test1.bmp", 10);
            //MessageBox.Show(test[0].ToString() + " " + test[1].ToString());
            dm.SetMouseDelay("windows", 80);
            //number 2
            if (dm.CmpColor(365, 311, "1aeff7", 1) == 0)
            {
             //   MessageBox.Show("Number 2 start");
                //số 3
                // lên
                if (dm.CmpColor(443, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                //Xuống
                if (dm.CmpColor(443, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                //Trái
                if (dm.CmpColor(443, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                //Phải
                if (dm.CmpColor(443, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }

                //số 4
                // lên
                if (dm.CmpColor(483, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                //Xuống
                if (dm.CmpColor(483, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                //Trái
                if (dm.CmpColor(483, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                //Phải
                if (dm.CmpColor(483, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                //Beat 
                while (dm.CmpColor(583, 316, "fff2d0", 1) == 1)
                {
                    dm.delay(10);

                }
                dm.MoveTo(111, 459);
                dm.LeftClick();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int handle = fun.gethandle();
            //   dm.ForceUnBindWindow(handle);
            dm.BindWindowEx(handle, "gdi", "windows", "windows", "", 0);
            var ret = dm.Capture(0, 0, 2000, 2000, "test.bmp");
            //int[] test = fun.FindXYImage(handle, "test1.bmp", 10);
            //MessageBox.Show(test[0].ToString() + " " + test[1].ToString());
            dm.SetMouseDelay("windows", 60);
            //number3
            if (dm.CmpColor(365, 311, "2ffcfd", 1) == 0)
            {
            //    MessageBox.Show("Number 3 start");
                // số 2 
                // lên
                if (dm.CmpColor(423, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                //Xuống
                if (dm.CmpColor(423, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                //Trái
                if (dm.CmpColor(423, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                //Phải
                if (dm.CmpColor(423, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                //số 3
                // lên
                if (dm.CmpColor(463, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                //Xuống
                if (dm.CmpColor(463, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                //Trái
                if (dm.CmpColor(463, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                //Phải
                if (dm.CmpColor(463, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }

                //số 4
                // lên
                if (dm.CmpColor(503, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                //Xuống
                if (dm.CmpColor(503, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                //Trái
                if (dm.CmpColor(503, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                //Phải
                if (dm.CmpColor(503, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                //Beat 
                while (dm.CmpColor(583, 316, "fff2d0", 1) == 1)
                {
                    dm.delay(10);

                }
                dm.MoveTo(111, 459);
                dm.LeftClick();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int handle = fun.gethandle();
            //   dm.ForceUnBindWindow(handle);
            dm.BindWindowEx(handle, "gdi", "windows", "windows", "", 0);
            var ret = dm.Capture(0, 0, 2000, 2000, "test.bmp");
            //int[] test = fun.FindXYImage(handle, "test1.bmp", 10);
            //MessageBox.Show(test[0].ToString() + " " + test[1].ToString());
            dm.SetMouseDelay("windows", 60);
          


                if (dm.CmpColor(365, 311, "33cd1e", 1) == 0)
                {
                //    MessageBox.Show("Number 4 start");
                    //Số 1
                    // lên
                    if (dm.CmpColor(403, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                    //Xuống
                    if (dm.CmpColor(403, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                    //Trái
                    if (dm.CmpColor(403, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                    //Phải
                    if (dm.CmpColor(403, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                    // số 2 
                    // lên
                    if (dm.CmpColor(443, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                    //Xuống
                    if (dm.CmpColor(443, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                    //Trái
                    if (dm.CmpColor(443, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                    //Phải
                    if (dm.CmpColor(443, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                    //số 3
                    // lên
                    if (dm.CmpColor(483, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                    //Xuống
                    if (dm.CmpColor(483, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                    //Trái
                    if (dm.CmpColor(483, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                    //Phải
                    if (dm.CmpColor(483, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }

                    //số 4
                    // lên
                    if (dm.CmpColor(523, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                    //Xuống
                    if (dm.CmpColor(523, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                    //Trái
                    if (dm.CmpColor(523, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                    //Phải
                    if (dm.CmpColor(523, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                //Beat 
                while (dm.CmpColor(583, 316, "fff2d0", 1) == 1)
                {
                        dm.delay(10);

                    }
                    dm.MoveTo(111, 459);
                    dm.LeftClick();

                }
                
           
            }

        private void button5_Click(object sender, EventArgs e)
        {
            int handle = fun.gethandle();
            //   dm.ForceUnBindWindow(handle);
            dm.BindWindowEx(handle, "gdi", "windows", "windows", "", 0);
            var ret = dm.Capture(0, 0, 2000, 2000, "test.bmp");
            //int[] test = fun.FindXYImage(handle, "test1.bmp", 10);
            //MessageBox.Show(test[0].ToString() + " " + test[1].ToString());
            dm.SetMouseDelay("windows", 80);
            while (true)
                {
                var start = dm.FindColor(451, 305, 547, 326, "fff2d0-000000|b86659-000000|ba2c17-000000|db8631-000000", 1, 0, out object x, out object y);
                intX = Convert.ToInt32(x);
               
                if ( intX > -1)
                   {
                  //  MessageBox.Show(intX.ToString());

                    // dm_number 1
                    if (dm.CmpColor(365, 311, "ffffff", 1) == 0)
                    {
                        //  MessageBox.Show("Number 1 start");
                        if (dm.CmpColor(463, 371, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(463, 371, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(463, 371, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(463, 371, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                        //Beat 
                        for (int i = 0; i < 400; i++)
                        {
                            dm.delay(10);
                            dm.FindColor(584, 308, 597, 326, "cd877c-000000|ce887d-000000|e49e94-000000", 0.90, 0, out x, out y);
                            intX = Convert.ToInt32(x);
                            if (intX > -1)
                            {
                               
                                dm.MoveTo(111, 459);
                                dm.LeftClick();
                            }
                            start = dm.FindColor(451, 305, 547, 326, "fff2d0-000000|b86659-000000|ba2c17-000000|db8631-000000", 1, 0, out x, out y);
                            intX = Convert.ToInt32(x);

                            if (intX > -1)
                            { break; }
                        }
                    }
                    if (dm.CmpColor(365, 311, "1aeff7", 1) == 0)
                    {
                        //   MessageBox.Show("Number 2 start");
                        //số 3
                        // lên
                        if (dm.CmpColor(443, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(443, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(443, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(443, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }

                        //số 4
                        // lên
                        if (dm.CmpColor(483, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(483, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(483, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(483, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                        //Beat 

                        for (int i = 0; i < 400; i++)
                        {
                            dm.delay(10);
                            dm.FindColor(584, 308, 597, 326, "cd877c-000000|ce887d-000000|e49e94-000000", 0.90, 0, out x, out y);
                            intX = Convert.ToInt32(x);
                            if (intX > -1)
                            {
                               
                                dm.MoveTo(111, 459);
                                dm.LeftClick();
                            }
                            start = dm.FindColor(451, 305, 547, 326, "fff2d0-000000|b86659-000000|ba2c17-000000|db8631-000000", 1, 0, out x, out y);
                            intX = Convert.ToInt32(x);

                            if (intX > -1)
                            { break; }
                        }
                    }
                        
                        
                    }
                    //number3
                    if (dm.CmpColor(365, 311, "2ffcfd", 1) == 0)
                    {
                        //    MessageBox.Show("Number 3 start");
                        // số 2 
                        // lên
                        if (dm.CmpColor(423, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(423, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(423, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(423, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                        //số 3
                        // lên
                        if (dm.CmpColor(463, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(463, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(463, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(463, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }

                        //số 4
                        // lên
                        if (dm.CmpColor(503, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(503, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(503, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(503, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                    //Beat 
                    for (int i = 0; i < 400; i++)
                    {
                        dm.delay(10);
                        dm.FindColor(584,308,597,326, "cd877c-000000|ce887d-000000|e49e94-000000",  0.90, 0, out x, out y);
                        intX = Convert.ToInt32(x);
                        if (intX > -1)
                        {
                           
                            dm.MoveTo(111, 459);
                            dm.LeftClick();
                        }
                        start = dm.FindColor(451, 305, 547, 326, "fff2d0-000000|b86659-000000|ba2c17-000000|db8631-000000", 1, 0, out x, out y);
                        intX = Convert.ToInt32(x);

                        if (intX > -1)
                        { break; }
                    }
                }
                if (dm.CmpColor(365, 311, "33cd1e", 1) == 0)
                {
                    //    MessageBox.Show("Number 4 start");
                    //Số 1
                    // lên
                    if (dm.CmpColor(403, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                    //Xuống
                    if (dm.CmpColor(403, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                    //Trái
                    if (dm.CmpColor(403, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                    //Phải
                    if (dm.CmpColor(403, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                    // số 2 
                   
                    // lên
                    if (dm.CmpColor(443, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                    //Xuống
                    if (dm.CmpColor(443, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                    //Trái
                    if (dm.CmpColor(443, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                    //Phải
                    if (dm.CmpColor(443, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                    //số 3
                   
                    // lên
                    if (dm.CmpColor(483, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                    //Xuống
                    if (dm.CmpColor(483, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                    //Trái
                    if (dm.CmpColor(483, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                    //Phải
                    if (dm.CmpColor(483, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                   
                    //số 4
                    // lên
                    if (dm.CmpColor(523, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                    //Xuống
                    if (dm.CmpColor(523, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                    //Trái
                    if (dm.CmpColor(523, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                    //Phải
                    if (dm.CmpColor(523, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                    //Beat 
                    for (int i = 0; i < 400; i++)
                    {
                        dm.delay(10);
                        dm.FindColor(584, 308, 597, 326, "cd877c-000000|ce887d-000000|e49e94-000000", 0.90, 0, out x, out y);
                        intX = Convert.ToInt32(x);
                        if (intX > -1)
                        {
                           
                            dm.MoveTo(111, 459);
                            dm.LeftClick();
                        }
                        start = dm.FindColor(451, 305, 547, 326, "fff2d0-000000|b86659-000000|ba2c17-000000|db8631-000000", 1, 0, out x, out y);
                        intX = Convert.ToInt32(x);

                        if (intX > -1)
                        { break; }
                    }
                }
                    //5k
                    if (dm.CmpColor(365, 311, "2bb61d", 1) == 0)
                    {
                        //    MessageBox.Show("Number 4 start");
                        //Số 1
                        // lên
                        if (dm.CmpColor(385, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(385, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(385, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(385, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                   
                    // số 2 
                    // lên
                    if (dm.CmpColor(423, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(423, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(423, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(423, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                   
                       // số 3
                        // lên
                        if (dm.CmpColor(463, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(463, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(463, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(463, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                   
                    //số 4
                    // lên
                    if (dm.CmpColor(503, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(503, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(503, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(503, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                   
                    //số5
                    // lên
                    if (dm.CmpColor(543, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(543, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(543, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(543, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                        //Beat 
                        for (int i = 0; i < 400; i++)
                        {
                            dm.delay(10);
                            dm.FindColor(584, 308, 597, 326, "cd877c-000000|ce887d-000000|e49e94-000000", 0.90, 0, out x, out y);
                            intX = Convert.ToInt32(x);
                            if (intX > -1)
                            {
                               
                                dm.MoveTo(111, 459);
                                dm.LeftClick();
                            }
                            start = dm.FindColor(451, 305, 547, 326, "fff2d0-000000|b86659-000000|ba2c17-000000|db8631-000000", 1, 0, out x, out y);
                            intX = Convert.ToInt32(x);

                            if (intX > -1)
                            { break; }
                        }

                    }
                    //6k
                    if (dm.CmpColor(365, 311, "fec106", 1) == 0)
                    {
                        //    MessageBox.Show("Number 4 start");
                        //Số 1
                        // lên
                        if (dm.CmpColor(364, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(364, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(364, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(364, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                   
                    // số 2 
                    // lên
                    if (dm.CmpColor(404, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(404, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(404, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(404, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                   
                    //số 3
                    // lên
                    if (dm.CmpColor(444, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(444, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(444, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(444, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                   
                    //số 4
                    // lên
                    if (dm.CmpColor(484, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(484, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(484, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(484, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                   
                    //số 5
                    // lên
                    if (dm.CmpColor(524, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(524, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(524, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(524, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                   
                    //số 6
                    // lên
                    if (dm.CmpColor(564, 370, "951e2f", 0.91) == 0) { dm.MoveTo(823, 358); dm.LeftClick(); }
                        //Xuống
                        if (dm.CmpColor(564, 370, "128926", 0.91) == 0) { dm.MoveTo(823, 489); dm.LeftClick(); }
                        //Trái
                        if (dm.CmpColor(564, 370, "8013d8", 0.91) == 0) { dm.MoveTo(758, 420); dm.LeftClick(); }
                        //Phải
                        if (dm.CmpColor(564, 370, "197ef2", 0.91) == 0) { dm.MoveTo(894, 421); dm.LeftClick(); }
                        //Beat 
                        for (int i = 0; i < 400; i++)
                        {
                            dm.delay(10);
                            dm.FindColor(584, 308, 597, 326, "cd877c-000000|ce887d-000000|e49e94-000000", 0.90, 0, out x, out y);
                            intX = Convert.ToInt32(x);
                            if (intX > -1)
                            {
                               
                                dm.MoveTo(111, 459);
                                dm.LeftClick();
                            }
                            start = dm.FindColor(451, 305, 547, 326, "fff2d0-000000|b86659-000000|ba2c17-000000|db8631-000000", 1, 0, out x, out y);
                            intX = Convert.ToInt32(x);

                            if (intX > -1)
                            { break; }
                        }

                    }dm.delay(19);
                } } 


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
          dm.UnBindWindow();


        }
           
        }
       
    }

