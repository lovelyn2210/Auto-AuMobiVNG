﻿using CShapDM;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Funcdm
{
    
    public class funcdm
    {
        CDmSoft dm = new CDmSoft();
        private int intX, intY;
        private object x, y;
        public string ImplementCmd(string value)
        {
            Process p = new Process();
            //setup 要启动的应用程序
            p.StartInfo.FileName = "cmd.exe";
            //是否使用操作系统shell启动
            p.StartInfo.UseShellExecute = false;
            // 接受来自调用程序的输入信息
            p.StartInfo.RedirectStandardInput = true;
            //输出信息
            p.StartInfo.RedirectStandardOutput = true;
            // 输出错误
            p.StartInfo.RedirectStandardError = true;
            //不显示程序窗口
            p.StartInfo.CreateNoWindow = true;


            //启动程序
            p.Start();
            //向cmd窗口发送输入信息
            p.StandardInput.WriteLine(value);
            p.StandardInput.WriteLine("exit");
            p.StandardInput.AutoFlush = true;
            //获取输出信息
            string strOuput = p.StandardOutput.ReadToEnd();
            //等待程序执行完退出进程
            if (p.WaitForExit(10000))
                p.Close();
            else
                p.Kill();

            return strOuput;
        }

        public int gethandle()
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\ChangZhi\LDPlayer");
            
            if (key == null)
            {
                MessageBox.Show("Không tìm thấy đường dẫn ldplayer 4 , vui lòng cài đặt nếu bạn chưa cài");
            }
            object objRegisteredValue = key.GetValue("InstallDir");
            string SimulatorPath = objRegisteredValue.ToString();
            
            /// <summary>
            /// View the status of the created simulator PS: In turn: index, title, top-level window handle, bound window handle, whether to enter android, process PID, VBox process PID
            /// </summary>
            /// <returns>Returns a List </returns>

            List<string> list = new List<string>();
                    string[] str = Regex.Split(ImplementCmd(
                        string.Format("{0}dnconsole list2",
                        SimulatorPath)), "\r\n", RegexOptions.IgnoreCase);
                    for (int i = 4; i < (str.Length - 3); i++)
                    {
                        list.Add(str[i]);
                    }
            

            var line = list[0];
            
            String[] strlist = line.Split(',');
            var hand = strlist[3];
            

            return int.Parse(hand.ToString());
            
            }

        public int WaitImage(int handle, string image, int TimeDelay)
        {
            
            int wait = 0;


            dm.BindWindowEx(handle, "gdi", "windows", "windows", "", 0);
            dm.FindPic(0, 0, 2000, 2000, image, "000000", 0.9, 0, out x, out y);
            intX = Convert.ToInt32(x);

            intY = Convert.ToInt32(y);
            while (intX == -1)
            {
                System.Threading.Thread.Sleep(1000);
                dm.FindPic(0, 0, 2000, 2000, image, "000000", 0.9, 0, out x, out y);
                intX = Convert.ToInt32(x);
                intY = Convert.ToInt32(y);

                if (intX != -1)
                {

                    dm.UnBindWindow();
                    return 1;
                }
                wait++;
                if (wait >= TimeDelay)
                {
                    dm.UnBindWindow();
                    return 0;
                }

            }

            dm.UnBindWindow();
            return 1;
        }
        public int WaitClickMultiColor(int handle, string fcolor, string color, int TimeDelay)
        {
            int wait = 0;


            dm.BindWindowEx(handle, "gdi", "windows", "windows", "", 0);

            dm.FindMultiColor(0, 0, 2000, 2000, fcolor, color, 0.9, 0, out x, out y);
            intX = Convert.ToInt32(x);

            intY = Convert.ToInt32(y);
           // MessageBox.Show(intX.ToString() + " " + intY.ToString());
            while (intX == -1)
            {
                System.Threading.Thread.Sleep(1000);
                dm.FindMultiColor(0, 0, 2000, 2000, fcolor, color, 1.0, 0, out x, out y);
                intX = Convert.ToInt32(x);
                intY = Convert.ToInt32(y);

                if (intX != -1)
                {
                    dm.MoveTo(intX, intY);
                    dm.LeftClick();
                    dm.UnBindWindow();
                    return 1;
                }
                wait++;
                if (wait >= TimeDelay)
                {
                    dm.UnBindWindow();
                    return 0;
                }

            }
            dm.MoveTo(intX, intY);
            dm.LeftClick();
            dm.UnBindWindow();

            return 1;
        }
        public int WaitToClick(int handle, string image, int TimeDelay)
        {
            int wait = 0;

            dm.BindWindowEx(handle, "gdi", "windows", "windows", "", 0);
            dm.FindPic(0, 0, 2000, 2000, image, "000000", 0.9, 0, out x, out y);
            intX = Convert.ToInt32(x);

            intY = Convert.ToInt32(y);
            while (intX == -1)
            {
                System.Threading.Thread.Sleep(1000);
                dm.FindPic(0, 0, 2000, 2000, image, "000000", 0.9, 0, out x, out y);
                intX = Convert.ToInt32(x);
                intY = Convert.ToInt32(y);

                if (intX != -1)
                {
                    dm.MoveTo(intX, intY);
                    dm.LeftClick();
                    dm.UnBindWindow();
                    return 1;
                }
                wait++;
                if (wait >= TimeDelay)
                {
                    dm.UnBindWindow();
                    return 0;
                }

            }
            dm.MoveTo(intX, intY);
            dm.LeftClick();
            dm.UnBindWindow();
            return 1;
        }
        public int ClickImage(int handle, string image)
        {


            dm.BindWindowEx(handle, "gdi", "windows", "windows", "", 0);
            dm.FindPic(0, 0, 2000, 2000, image, "000000", 0.9, 0, out x, out y);
            intX = Convert.ToInt32(x);
            intY = Convert.ToInt32(y);
            
            if (intX == -1)
            {
                return 0;
            }

            dm.MoveTo(intX, intY);
            dm.LeftClick();

            dm.UnBindWindow();
            return 1;
        }
        public int[] FindXYImage(int handle, string image, int TimeDelay)
        {

            int wait = 0;
            int[] result;

            dm.BindWindowEx(handle, "gdi", "windows", "windows", "", 0);
            dm.FindPic(0, 0, 2000, 2000, image, "000000", 0.9, 0, out x, out y);
            intX = Convert.ToInt32(x);

            intY = Convert.ToInt32(y);
            if (intX == -1)
            {
                dm.UnBindWindow();
                result = new int[] { intX, intY };
                return result;
            }
               
          

                dm.UnBindWindow();
             result = new int[] { intX, intY };
            return result;
        }
        

    }
}
